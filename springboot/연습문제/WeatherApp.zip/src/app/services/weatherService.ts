import { CurrentWeather, DailyForecast, HourlyForecast } from '../types/weather';

// OpenWeather API 설정
// 실제 사용 시 API 키를 여기에 입력하세요: https://openweathermap.org/api
const API_KEY = 'YOUR_API_KEY_HERE';
const BASE_URL = 'https://api.openweathermap.org/data/2.5';

// 실제 API 호출 함수 (주석 처리됨)
/*
export async function fetchCurrentWeather(city: string): Promise<CurrentWeather> {
  const response = await fetch(
    `${BASE_URL}/weather?q=${city}&appid=${API_KEY}&units=metric&lang=kr`
  );
  const data = await response.json();
  
  return {
    location: data.name,
    temperature: Math.round(data.main.temp),
    feelsLike: Math.round(data.main.feels_like),
    windSpeed: data.wind.speed,
    description: data.weather[0].description,
    icon: data.weather[0].icon,
    aqi: 0, // AQI는 별도 API 호출 필요
    aqiLevel: '보통'
  };
}

export async function fetchForecast(city: string): Promise<{ daily: DailyForecast[], hourly: HourlyForecast[] }> {
  const response = await fetch(
    `${BASE_URL}/forecast?q=${city}&appid=${API_KEY}&units=metric&lang=kr`
  );
  const data = await response.json();
  
  // 데이터 가공 로직...
}
*/

// Mock 데이터 (개발용)
export async function fetchCurrentWeather(city: string): Promise<CurrentWeather> {
  // 실제 환경에서는 위의 주석 처리된 코드를 사용하세요
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        location: '서울특별시',
        temperature: 8,
        feelsLike: 6,
        windSpeed: 3,
        description: '맑음',
        icon: '01d',
        aqi: 89,
        aqiLevel: '보통'
      });
    }, 500);
  });
}

export async function fetchForecast(city: string): Promise<{ daily: DailyForecast[], hourly: HourlyForecast[] }> {
  // 실제 환경에서는 위의 주석 처리된 코드를 사용하세요
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        daily: [
          {
            day: '내일',
            tempHigh: 10,
            tempLow: 2,
            icon: '02d',
            description: '구름 조금'
          },
          {
            day: '토요일',
            tempHigh: 12,
            tempLow: 4,
            icon: '01d',
            description: '맑음'
          }
        ],
        hourly: [
          { time: '17:00', temperature: 8, icon: '01d' },
          { time: '18:00', temperature: 7, icon: '01d' },
          { time: '19:00', temperature: 6, icon: '01n' },
          { time: '20:00', temperature: 5, icon: '01n' }
        ]
      });
    }, 500);
  });
}