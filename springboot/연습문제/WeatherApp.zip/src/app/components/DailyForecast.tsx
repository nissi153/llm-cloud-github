import { DailyForecast as DailyForecastType } from '../types/weather';
import styles from './DailyForecast.module.css';
import sunIcon from 'figma:asset/2b2f13f256f6fa965e70edee93efc9b545d17c7e.png';

interface Props {
  forecasts: DailyForecastType[];
}

export function DailyForecast({ forecasts }: Props) {
  const getWeatherIcon = (icon: string) => {
    // 맑은 날씨일 때 커스텀 아이콘 사용
    if (icon === '01d' || icon === '01n') {
      return sunIcon;
    }
    return `https://openweathermap.org/img/wn/${icon}@2x.png`;
  };

  return (
    <div className={styles.container}>
      <h2 className={styles.title}>일별 예보</h2>
      <div className={styles.forecastGrid}>
        {forecasts.map((forecast, index) => (
          <div key={index} className={styles.forecastCard}>
            <div className={styles.day}>{forecast.day}</div>
            <div className={styles.weatherInfo}>
              <img 
                src={getWeatherIcon(forecast.icon)} 
                alt={forecast.description}
                className={styles.icon}
              />
              <div className={styles.temps}>
                <div className={styles.tempHigh}>{forecast.tempHigh}°</div>
                <div className={styles.tempLow}>{forecast.tempLow}°</div>
              </div>
            </div>
            <div className={styles.description}>{forecast.description}</div>
          </div>
        ))}
      </div>
    </div>
  );
}